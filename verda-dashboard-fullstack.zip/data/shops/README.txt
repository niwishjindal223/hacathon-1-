Shop JSON files are created here automatically when the local backend first saves a shop.
