'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { pipeline } = require('node:stream');

const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT) || 4173;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const SHOPS_DIR = path.join(ROOT, 'data', 'shops');
const DEMO_FILE = path.join(ROOT, 'data', 'demo-state.json');
const MAX_BODY = 8 * 1024 * 1024;
const SAFE_FIELDS = [
  'shopSettings', 'currentUser', 'notifications', 'customers', 'suppliers', 'inventory', 'sales', 'purchases',
  'expenses', 'staff', 'recentRetentionActions', 'auditLogs', 'nearbyPulseOptIn',
  'nearbyStockSignals', 'nearbyQuoteRequests'
];

function sendJson(res, status, body) {
  const data = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': data.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(data);
}

function validShopId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(value);
}

function shopFile(shopId) {
  if (!validShopId(shopId)) return null;
  return path.join(SHOPS_DIR, `${shopId}.json`);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(Object.assign(new Error('Request body too large'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(Object.assign(new Error('Invalid JSON body'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

async function handleApi(req, res, url) {
  if (url.pathname === '/api/health' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, storage: 'local-json', host: HOST });
  }
  if (url.pathname !== '/api/state') return false;

  if (req.method === 'GET') {
    const shopId = url.searchParams.get('shopId');
    const file = shopFile(shopId);
    if (!file) return sendJson(res, 400, { error: 'A valid shopId is required.' });
    try {
      const state = JSON.parse(await fs.promises.readFile(file, 'utf8'));
      return sendJson(res, 200, { found: true, state });
    } catch (error) {
      if (error.code !== 'ENOENT') return sendJson(res, 500, { error: 'Could not read saved shop data.' });
      if (shopId === 'SHOP-01') {
        try {
          const state = JSON.parse(await fs.promises.readFile(DEMO_FILE, 'utf8'));
          return sendJson(res, 200, { found: false, source: 'demo-seed', state });
        } catch { /* The frontend's own seed data remains available. */ }
      }
      return sendJson(res, 200, { found: false, state: null });
    }
  }

  if (req.method === 'PUT') {
    let payload;
    try { payload = await readBody(req); }
    catch (error) { return sendJson(res, error.status || 400, { error: error.message }); }
    const file = shopFile(payload.shopId);
    const state = payload.state;
    if (!file || !state || typeof state !== 'object' || Array.isArray(state)
      || !Array.isArray(state.customers) || !Array.isArray(state.inventory)) {
      return sendJson(res, 400, { error: 'Invalid shop state.' });
    }
    const safeState = Object.fromEntries(SAFE_FIELDS.filter(key => key in state).map(key => [key, state[key]]));
    try {
      await fs.promises.mkdir(SHOPS_DIR, { recursive: true });
      await fs.promises.writeFile(file, JSON.stringify(safeState, null, 2), 'utf8');
      return sendJson(res, 200, { ok: true, shopId: payload.shopId });
    } catch { return sendJson(res, 500, { error: 'Could not save shop data.' }); }
  }

  if (req.method === 'DELETE') {
    if (url.searchParams.get('all') === 'true') {
      try {
        await fs.promises.mkdir(SHOPS_DIR, { recursive: true });
        const files = await fs.promises.readdir(SHOPS_DIR);
        await Promise.all(files.filter(name => /^[A-Za-z0-9_-]{1,64}\.json$/.test(name))
          .map(name => fs.promises.rm(path.join(SHOPS_DIR, name), { force: true })));
        await fs.promises.rm(DEMO_FILE, { force: true });
        return sendJson(res, 200, { ok: true, deleted: 'all-shops-and-demo-seed' });
      } catch { return sendJson(res, 500, { error: 'Could not clear saved shop data.' }); }
    }
    const shopId = url.searchParams.get('shopId');
    const file = shopFile(shopId);
    if (!file) return sendJson(res, 400, { error: 'A valid shopId is required.' });
    try {
      await fs.promises.rm(file, { force: true });
      if (shopId === 'SHOP-01') await fs.promises.rm(DEMO_FILE, { force: true });
      return sendJson(res, 200, { ok: true, shopId, demoSeedRemoved: shopId === 'SHOP-01' });
    } catch { return sendJson(res, 500, { error: 'Could not clear saved shop data.' }); }
  }

  res.setHeader('Allow', 'GET, PUT, DELETE');
  return sendJson(res, 405, { error: 'Method not allowed.' });
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon'
};

const server = http.createServer(async (req, res) => {
  let url;
  try { url = new URL(req.url, `http://${HOST}:${PORT}`); }
  catch { return sendJson(res, 400, { error: 'Bad request URL.' }); }

  if (url.pathname.startsWith('/api/')) {
    const handled = await handleApi(req, res, url);
    if (handled !== false) return;
    return sendJson(res, 404, { error: 'API route not found.' });
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' });
    return res.end('Method not allowed');
  }
  let pathname;
  try { pathname = decodeURIComponent(url.pathname); }
  catch { res.writeHead(400); return res.end('Bad path'); }
  if (pathname === '/') pathname = '/index.html';
  const file = path.resolve(PUBLIC_DIR, `.${pathname}`);
  if (!file.startsWith(PUBLIC_DIR + path.sep) && file !== path.join(PUBLIC_DIR, 'index.html')) {
    res.writeHead(403); return res.end('Forbidden');
  }
  try {
    const stat = await fs.promises.stat(file);
    if (!stat.isFile()) throw new Error('Not a file');
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': stat.size,
      'X-Content-Type-Options': 'nosniff'
    });
    if (req.method === 'HEAD') return res.end();
    pipeline(fs.createReadStream(file), res, error => { if (error) res.destroy(error); });
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Verda is running at http://${HOST}:${PORT}`);
  console.log('Data is saved as JSON under data/shops. The server only listens on this computer.');
});
