# Verda Shop Dashboard

This bundle contains the Verda dashboard, a small Node.js backend, and JSON demo data.

## Run it

1. Install Node.js 18 or later.
2. Extract this ZIP to a folder.
3. Open a terminal in the extracted folder and run `npm start` (or run `start.bat` on Windows).
4. Open http://127.0.0.1:4173.

The dashboard uses the JSON backend when served from this local server. If opened directly as an HTML file, it falls back to browser storage.

## Included files

- `public/index.html` — the complete dashboard UI and frontend logic.
- `server.js` — built-in Node.js HTTP server and JSON state API. No npm packages are required.
- `data/demo-state.json` — sample shop data loaded for the first demo run.
- `data/shops/` — per-shop JSON files are created here as you make changes.
- `package.json` — start command and Node version requirement.

The server binds to `127.0.0.1` only. It is meant for local use and has no login, encryption, or multi-user network security. Do not expose it to the internet or a shared network without adding authentication and access controls. The frontend loads Tailwind CSS, Chart.js, and Lucide from their existing CDN URLs, so those visual libraries need internet access.

The Settings reset controls now clear demo records and saved shop data. The all-data reset also removes the bundled demo JSON seed from the local backend. Nearby shop signals, distributor listings, and quote requests are still demo/local-only. They do not contact real businesses or use live location data.
